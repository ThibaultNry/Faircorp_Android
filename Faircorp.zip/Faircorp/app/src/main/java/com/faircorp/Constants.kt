package com.faircorp

object Constants {
    const val WINDOW_NAME_PARAM = "com.faircorp.windowname.attribute"
}